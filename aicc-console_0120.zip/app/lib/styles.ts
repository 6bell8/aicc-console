export const LIST_ROW_HOVER_BG = 'hover:bg-gray-100 dark:hover:bg-gray-800';
export const LIST_ROW_BG_ACTIVE = 'bg-gray-100 dark:bg-gray-800'; // 필요하면
